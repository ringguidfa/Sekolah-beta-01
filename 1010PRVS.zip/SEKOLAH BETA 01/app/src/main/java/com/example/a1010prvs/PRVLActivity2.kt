package com.example.a1010prvs

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class PRVLActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prvlactivity2)
    }
}